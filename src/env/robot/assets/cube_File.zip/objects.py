import copy
import xml.etree.ElementTree as ET
import numpy as np
from env.robot.assets.base import MujocoXML
from env.robot.assets.mjcf_utils import string_to_array, array_to_string


class MujocoObject:

    def __init__(self):
        self.asset = ET.Element("asset")

    def get_horizontal_radius(self):
        raise NotImplementedError

    def get_collision(self, name=None, site=False):
        raise NotImplementedError

    def get_site_attrib_template(self):
        return {
            "pos": "0 0 0",
            "size": "0.006 0.006 0.006",
            "rgba": "1 0 0 1",
            "type": "sphere",
        }

class MujocoXMLObject(MujocoXML, MujocoObject):

    def __init__(self, fname):

        MujocoXML.__init__(self, fname)

    def get_horizontal_radius(self):
        horizontal_radius_site = self.worldbody.find("./body/site[@name='horizontal_radius_site']")
        return string_to_array(horizontal_radius_site.get("pos"))[0]

    def get_collision(self, name=None, site=False):

        collision = copy.deepcopy(self.worldbody.find("./body/body[@name='collision']"))
        collision.attrib.pop("name")
        if name is not None:
            collision.attrib["name"] = name
            geoms = collision.findall("geom")
            if len(geoms) == 1:
                geoms[0].set("name", name)
            else:
                for i in range(len(geoms)):
                    geoms[i].set("name", "{}-{}".format(name, i))
        if site:
            template = self.get_site_attrib_template()
            template["rgba"] = "1 1 0 1"
            if name is not None:
                template["name"] = name
            collision.append(ET.Element("site", attrib=template))
        return collision
