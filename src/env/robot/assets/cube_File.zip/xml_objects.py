from env.robot.assets.objects import MujocoXMLObject
from env.robot.assets.mjcf_utils import xml_path_completion

class CubeObject(MujocoXMLObject):

    def __init__(self):
        super().__init__(xml_path_completion("robot/cube.xml"))

